var reporter = require('cucumber-html-reporter');
var args = process.argv.slice(2)

cucumber_option = args[0]
console.log(cucumber_option)

var options = cucumber_option;
reporter.generate(JSON.parse(options));
