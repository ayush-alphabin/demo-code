import json
import os.path
import shutil
import subprocess


class CucumberReport:
    """
    pass json value to cucumber_option
    cucumber_option = {
        'theme': 'bootstrap',
        'jsonFile': <path to cucumber json file>,
        'output': <path to cucumber output file>,
        'reportSuiteAsScenarios': True,
        'scenarioTimestamp': True,
        'launchReport': False,
        'metadata': {
            'Test Environment': 'environment',
            'Application End Point': 'application_url'
        }
    }
    """
    @staticmethod
    def generate_html(cucumber_option):

        node_locate = shutil.which("node")
        fn = os.path.join(os.path.dirname(__file__), 'cucumber_json_to_html_converter.js')
        p = subprocess.Popen([node_locate,
                              fn,
                              json.dumps(cucumber_option)],
                             stdout=subprocess.PIPE)
        out = p.stdout.read()
        print(out)
