
import great_expectations as gx
from great_expectations.cli.datasource import sanitize_yaml_and_save_datasource
from great_expectations.core.batch import BatchRequest
from apiservice.Logger.Logger import Logger

class suitevalidator:

    @staticmethod
    def createSuiteValidator(SuiteName, DataSource, assetname):
        context = gx.data_context.DataContext()
        suite = context.add_expectation_suite(SuiteName,)
        batch_request = BatchRequest(
            datasource_name=DataSource,
            data_connector_name="default_inferred_data_connector_name",
            data_asset_name=assetname
        )
        validator = context.get_validator(batch_request=batch_request, expectation_suite=suite)
        Logger.log_info('Suite validater is created with suite name'+ SuiteName)
        return validator