from pprint import pprint

from ruamel.yaml import YAML
import great_expectations as gx

class checkpoint:

    @staticmethod
    def createNewCheckPoint(name, suiteName, assetName, dataSource):
        yaml = YAML()
        context = gx.get_context()
        my_checkpoint_name = name  # This was populated from your CLI command.
        yaml_config = f"""
         name: {my_checkpoint_name}
         config_version: 1.0
         class_name: SimpleCheckpoint
         run_name_template: "%Y%m%d-%H%M%S-my-run-name-template"
         validations:
          - batch_request:
              datasource_name: {dataSource}
              data_connector_name: default_inferred_data_connector_name
              data_asset_name: {assetName}
              data_connector_query:
                index: -1
            expectation_suite_name: {suiteName}
         """
        print(yaml_config)
        # Run this cell to print out the names of your Datasources, Data Connectors and Data Assets
        pprint(context.get_available_data_asset_names())
        context.list_expectation_suite_names()
        my_checkpoint = context.test_yaml_config(yaml_config=yaml_config)
        print(my_checkpoint.get_config(mode="yaml"))
        context.add_checkpoint(**yaml.load(yaml_config))