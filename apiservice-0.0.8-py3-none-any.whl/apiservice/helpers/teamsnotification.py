import pymsteams
import datetime
from apiservice.Logger.Logger import Logger


class TeamsNotification:
    def __init__(self, webhook, verify_ssl):
        self.webhook = webhook
        self.verify_ssl = verify_ssl
        self.connector = self.teams_connector()

    def teams_connector(self):
        return pymsteams.connectorcard(self.webhook, self.verify_ssl)

    def prepare_summary_and_send_notification(self, summary_data, template="BASIC"):
        # Push summary notification to teams
        if template == "BASIC":
            my_teams_message = self.connector
            my_message_section = pymsteams.cardsection()
            current_time = datetime.datetime.now()
            my_teams_message.text(str(current_time))
            my_message_section.title(summary_data["title"])
            my_message_section.activityTitle(summary_data["activity-title"])
            meta_data = summary_data['meta-data']
            facts = summary_data['facts']
            self.add_fact(meta_data, my_message_section)
            self.add_fact(facts, my_message_section)
            my_teams_message.addSection(my_message_section)
            my_teams_message.send()
        else:
            Logger.log_error(f"Template: {template} Not Implemented")

    def add_fact(self, data_map, message_section):
        for key in data_map:
            value = data_map[key]
            message_section.addFact(key, value)
