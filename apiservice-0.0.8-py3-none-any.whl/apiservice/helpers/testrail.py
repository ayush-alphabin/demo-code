import base64
import json

# from dotenv import load_dotenv
import requests
from apiservice.config import global_configs


class APIClient:
    def __init__(self, base_url):
        self.user = ""
        self.password = ""
        if not base_url.endswith("/"):
            base_url += "/"
        self.__url = base_url + "index.php?/api/v2/"

    def send_get(self, uri, filepath=None):
        """Issue a GET request (read) against the API.

        Args:
            uri: The API method to call including parameters, e.g. get_case/1.
            filepath: The path and file name for attachment download; used only
                for 'get_attachment/:attachment_id'.

        Returns:
            A dict containing the result of the request.
        """
        return self.__send_request("GET", uri, filepath)

    def send_post(self, uri, data):
        """Issue a POST request (write) against the API.

        Args:
            uri: The API method to call, including parameters, e.g. add_case/1.
            data: The data to submit as part of the request as a dict; strings
                must be UTF-8 encoded. If adding an attachment, must be the
                path to the file.

        Returns:
            A dict containing the result of the request.
        """
        return self.__send_request("POST", uri, data)

    def __send_request(self, method, uri, data):
        url = self.__url + uri

        auth = str(
            base64.b64encode(bytes("%s:%s" % (self.user, self.password), "utf-8")),
            "ascii",
        ).strip()
        headers = {"Authorization": "Basic " + auth}

        if method == "POST":
            if uri[:14] == "add_attachment":  # add_attachment API method
                files = {"attachment": (open(data, "rb"))}
                response = requests.post(url, headers=headers, files=files)
                files["attachment"].close()
            else:
                headers["Content-Type"] = "application/json"
                payload = bytes(json.dumps(data), "utf-8")
                response = requests.post(url, headers=headers, data=payload)
        else:
            headers["Content-Type"] = "application/json"
            response = requests.get(url, headers=headers)

        if response.status_code > 201:
            try:
                error = response.json()
            except:  # response.content not formatted as JSON
                error = str(response.content)
            raise APIError(
                "TestRail API returned HTTP %s (%s)" % (response.status_code, error)
            )
        else:
            if uri[:15] == "get_attachment/":  # Expecting file, not JSON
                try:
                    open(data, "wb").write(response.content)
                    return data
                except:
                    return "Error saving attachment."
            else:
                try:
                    return response.json()
                except:  # Nothing to return
                    return {}


class APIError(Exception):
    pass


if global_configs.testrail.lower() == "true":
    client = APIClient(global_configs.testrail_endpoint)
    client.user = global_configs.testrail_user
    client.password = global_configs.testrail_password


class Testrail:
    @staticmethod
    # Get the project ID using project name
    def get_project_id(project_name):
        project_id = None
        try:
            projects = client.send_get("get_projects")
            print(projects)
        except Exception as e:
            print("Exception in get_project_id() get project id.")
            print("PYTHON SAYS: ")
            print(e)
        else:
            project_length = len(projects["projects"])
            for i in range(project_length):
                if projects["projects"][i]["name"] == project_name:
                    project_id = projects["projects"][i]["id"]
        return project_id

    @staticmethod
    # Get the run ID using test name and project name
    def get_run_id(project_name):
        # run_id = None
        project_id = Testrail.get_project_id(project_name)
        try:
            test_runs = client.send_get("get_runs/%s" % (project_id))
            print("Id is here", test_runs["id"])
        except Exception as e:
            print("Exception in get_run_id() get run id.")
            print("PYTHON SAYS: ")
            print(e)
        # else:
        #     if test_runs["name"] == test_run_name:
        #         run_id = test_runs["id"]
        # print(test_runs["id"])
        # return test_runs["id"]

    @staticmethod
    # Create a new plan if it does not already exist
    def add_plan(new_plan_name, description, project_id, new_plan_entry_name, CASE_ID):
        print(CASE_ID)
        try:
            new_plan = client.send_post(
                "add_plan/%s" % (project_id),
                {"name": new_plan_name, "description": description},
            )
            plan_id = new_plan["id"]
            print("New plan id", new_plan)
            new_run_id = Testrail.add_plan_entry(new_plan_entry_name, plan_id, CASE_ID)
            print("plan id", plan_id)
            return new_run_id
        except Exception as e:
            print("Exception in add_plan() creating new plan.")
            print("PYTHON SAYS: ")
            print(e)

    @staticmethod
    # Add plan entry
    def add_plan_entry(new_plan_entry_name, plan_id, CASE_ID):
        try:
            new_plan = client.send_post(
                "add_plan_entry/%s" % (plan_id),
                {
                    "name": new_plan_entry_name,
                    "suite_id": 1,
                    "include_all": False,
                    "case_ids": CASE_ID,
                },
            )
            run_id = new_plan["runs"][0]["id"]
            print("New run id is here", run_id)
            return run_id
        except Exception as e:
            print("Exception in add_plan_entry() add plan entry.")
            print("PYTHON SAYS: ")
            print(e)

    @staticmethod
    # Create a new suit if it does not already exist
    def add_suite(new_suite_name, project_id):
        try:
            new_suit = client.send_post(
                "add_suite/%s" % (project_id), {"name": new_suite_name}
            )
        except Exception as e:
            print("Exception in add_suite() creating new suite.")
            print("PYTHON SAYS: ")
            print(e)

    @staticmethod
    # Create a new test run if it does not already exist
    def add_test_run(new_test_run_name, project_id):
        try:
            new_test_run = client.send_post(
                "add_run/%s" % (project_id),
                {"name": new_test_run_name, "include_all": False},
            )
            # print(new_test_run)
            # print(new_test_run["id"])
        except Exception as e:
            print("Exception in add_test_run() creating new test run.")
            print("PYTHON SAYS: ")
            print(e)
        return new_test_run["id"]

    @staticmethod
    # update a test run
    def update_test_run(run_id, case_ids):
        try:
            update_test_run = client.send_post(
                "update_run/%s" % (run_id), {"include_all": False, "case_ids": case_ids}
            )

        except Exception as e:
            print("Exception in add_test_run() creating new test run.")
            print("PYTHON SAYS: ")
            print(e)

    @staticmethod
    # Create a new test case if it does not already exist
    def add_test_case(new_test_case_title, project_id):
        try:
            new_test_case = client.send_post(
                "add_case/%s" % (project_id), {"title": new_test_case_title}
            )
        except Exception as e:
            print("Exception in add_test_case() creating new test case.")
            print("PYTHON SAYS: ")
            print(e)

    @staticmethod
    # Update TestRail for a given run_id and case_id
    def update_testrail(case_id, run_id, result_flag, msg=""):
        update_flag = True
        # status_id is 1 for Passed, 2 For Blocked, 4 for Retest and 5 for Failed
        status_id = 1 if result_flag == "passed" else 5

        if (run_id is not None) and (case_id != "None"):
            try:
                client.send_post(
                    "add_result_for_case/%s/%s" % (run_id, case_id),
                    {"status_id": status_id, "comment": msg},
                )
            except Exception as e:
                print("Exception in update_testrail() updating TestRail.")
                print("PYTHON SAYS: ")
                print(e)
            else:
                print(
                    "Updated test result for case: %s in test run: %s\n"
                    % (case_id, run_id)
                )
        return update_flag

    @staticmethod
    # Delete an existing test run
    def delete_test_run(test_run_name, project_name):
        run_id = Testrail.get_run_id(test_run_name, project_name)
        if run_id is not None:
            try:
                client.send_post("delete_run/%s" % (run_id), test_run_name)
            except Exception as e:
                print("Exception in update_testrail() updating TestRail.")
                print("PYTHON SAYS: ")
                print(e)
        else:
            print(
                "Cant delete the test run for given project and test run name: %s , %s"
                % (project_name, test_run_name)
            )
