import logging
import time
from apiservice.config.utils import utils

utils.makeDir("report")
logger = logging.getLogger()
log_level = ""
formatter = logging.Formatter('%(asctime)s | %(name)s | %(levelname)s | %(message)s')
timestamp = int(time.time())
fh = logging.FileHandler('./report/TestReport' + str(timestamp) + '.log')
fh.setFormatter(formatter)
consoleHandler = logging.StreamHandler()
consoleHandler.setFormatter(formatter)
logger.addHandler(consoleHandler)
logger.addHandler(fh)


class Logger:
    @staticmethod
    def log_info(message):
        logger.setLevel(logging.INFO)
        fh.setFormatter(formatter)
        logger.addHandler(fh)
        logger.info(message)

    @staticmethod
    def log_error(message):
        logger.setLevel(logging.ERROR)
        fh.setFormatter(formatter)
        logger.addHandler(fh)
        logger.error(message)

    @staticmethod
    def log_debug(message):
        logger.setLevel(logging.DEBUG)
        fh.setFormatter(formatter)
        logger.addHandler(fh)
        logger.debug(message)

    @staticmethod
    def log_print(message):
        if log_level == "info":
            return Logger.log_info(message)
        elif log_level == "debug":
            return Logger.log_debug(message)
        elif log_level == "error":
            return Logger.log_error(message)
        else:
            return Exception("Logger level is not set")
