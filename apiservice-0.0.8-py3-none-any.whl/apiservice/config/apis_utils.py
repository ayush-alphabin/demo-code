import json
import string
import jsonschema
import datetime
import pytest
import requests
import random
import exrex
import ssl
import secrets
from cerberus import Validator
from apiservice.config.utils import utils
from apiservice.Logger.Logger import Logger


class apis_utils:
    @staticmethod
    def call_api(
            url, method, payload={}, headers={}, auth={}, cookie={}, timeout=100, params={}, verify=True
    ):
        try:
            ssl.match_hostname = lambda cert, hostname: True
            _response = method(
                url,
                data=payload,
                headers=headers,
                auth=auth,
                params=params,
                timeout=timeout,
                verify=verify
            )
        except Exception as e:
            Logger.log_error(e)
            raise Exception
        return _response

    @staticmethod
    def verify_status_codes(response, expected_status_code):
        Logger.log_debug(
            "API_Response - {} with status code - {}".format(
                str(response), str(response.status_code)
            )
        )
        assert (
                response.status_code == expected_status_code
        ), f"Expected Status Code {expected_status_code} and Actual status {response.status_code} code did match " \
           f"and response is {response.json()}"
        return response

    @staticmethod
    def verify_response_field(response_field_value, expected_value, info_message=None, failure_message=None):
        failure_message = failure_message if (
                failure_message is not None) else f"Expected Value {expected_value} and Actual response field value {response_field_value} code did not match"
        info_message = info_message if (
                info_message is not None) else f"Actual Response field {str(response_field_value)} and Expected Response field {str(expected_value)}"
        Logger.log_info(info_message)
        assert (response_field_value == expected_value), failure_message

    @staticmethod
    def validate_response_field_isNotNull(response_field_value):
        assert (
                response_field_value is not None
        ), f"response field value is {response_field_value} but it should not be null"

    @staticmethod
    def validate_response_field_isNull(response_field_value):
        assert (
                response_field_value is None
        ), f"response field value is {response_field_value} but it should be null"

    @staticmethod
    def response_match(actual_response, expected_response, object_type="xml"):
        if object_type == 'xml':
            isEqual = utils.xml_compare(utils.convert_string_to_tree(actual_response),
                                        utils.convert_string_to_tree(expected_response))
            assert (isEqual is True), f"response not matched as expected: " \
                                      f"\nExpected value --> {expected_response} " \
                                      f"\nActual value --> {actual_response} "
        else:
            diff = utils.json_compare(actual_response, expected_response)
            assert diff == {}, f"response not matched as expected \n--difference--\n {diff} " \
                               f"\n-----------------\nExpected value --> {expected_response} " \
                               f"\n Actual value --> {actual_response} "

    # Get json ResponseSchema file
    @staticmethod
    def get_schema(schema):
        # This function loads the given ResponseSchema available
        with open(schema, "r") as file:
            schema = json.load(file)
        return schema

    # Schema validation method
    @staticmethod
    def validate_schema(json_data, schema):
        # Describe what kind of json you expect.
        schema = apis_utils.get_schema(schema)
        validator = Validator(schema)
        is_valid = validator.validate(json_data)
        assert (is_valid) == True

    # Headers
    @staticmethod
    def getHeaders():
        headers = {"Content-Type": "application/json"}
        return headers

    # uniqueId headers
    @staticmethod
    def getAppAccessTokenHeaders(appAccessToken):
        headers = {"Content-Type": "application/json",
                   "Accept": "application/json",
                   "Authorization": appAccessToken}
        return headers

    # uniqueId headers
    @staticmethod
    def getUniqueIdHeaders(uniqueId):
        headers = {"Content-Type": "application/json", "uniqueId": uniqueId}
        return headers

    # datetime function
    @staticmethod
    def getDateTime():
        return datetime.datetime.now()

    # generate random riskProfileId
    @staticmethod
    def get_riskProfiled():
        riskProfileId = random.randint(1, 5)
        return riskProfileId

    # Random contactNumber generate method
    @staticmethod
    def generate_contactNumber():
        first = str(random.randint(600, 999))
        second = str(random.randint(1, 888)).zfill(3)

        last = str(random.randint(1, 9998)).zfill(4)
        while last in ["1111", "2222", "3333", "4444", "5555", "6666", "7777", "8888"]:
            last = str(random.randint(1, 9998)).zfill(4)

        return "{}{}{}".format(first, second, last)

    # Random deviceId generate method
    @staticmethod
    def generate_deviceUniqueId():
        N = 16
        deviceUniqueId = exrex.getone(
            "[1-9]{3}[a-f][0-9][a-f][0-9]{6}[a-f][0-9][a-f]{2}"
        )
        return str(deviceUniqueId)

    # generate PAN number method
    @staticmethod
    def generate_PAN():
        PAN = exrex.getone(r"([A-Z]{5})([0-9]{4})([A-Z]{1})")
        return PAN

    domains = [
        "hotmail.com",
        "gmail.com",
        "aol.com",
        "mail.com",
        "mail.kz",
        "yahoo.com",
    ]
    letters = ["a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l"]

    @staticmethod
    def get_one_random_domain(domains):
        return domains[random.randint(0, len(domains) - 1)]

    @staticmethod
    def get_one_random_name(letters):
        email_name = ""
        for i in range(7):
            email_name = email_name + letters[random.randint(0, 11)]
        return email_name

    # generate email method
    @staticmethod
    def generate_email():
        one_name = str(apis_utils.get_one_random_name(apis_utils.letters))
        one_domain = str(apis_utils.get_one_random_domain(apis_utils.domains))
        mail = one_name + "@" + one_domain
        return mail

    # generate Mpin
    @staticmethod
    def generate_Mpin():
        Mpin = exrex.getone(r"([0-9]{4})")
        return Mpin

    # generate string
    @staticmethod
    def generate_nomineeName():
        nomineeName = exrex.getone(r"([a-z]{4})")
        return nomineeName

    # generate random subCategory for Notification
    @staticmethod
    def get_Notification_subCategory():
        subCategory = ['Orders', 'Rebalance', 'Family', 'App Updates', 'Upcoming Payments']
        choice = (secrets.choice(subCategory))
        return choice

    # # generate date-time
    # @staticmethod
    # def generate_dateTime():
    #     TodayDate = datetime.today().strftime('%Y-%m-%d')
    #     return TodayDate

    # Generates a numeric string of unique numbers.
    # Length of the string depends on the argument passed.
    @staticmethod
    def get_numeric_string(length):
        s = ''
        for i in range(0, length):
            random_integer = random.randint(0, 9)
            s = s + str(random_integer)
        return s

    # Generates a unique number.
    # The number to picked between is dependent on the start and end range.
    @staticmethod
    def get_random_number(start, end):
        return random.randint(start, end)


class RequestTypes:
    GET = requests.get
    POST = requests.post
    PUT = requests.put
    DELETE = requests.delete
