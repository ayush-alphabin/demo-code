import os

from dotenv import load_dotenv

load_dotenv()

influxUrl = ""
influxToken = ""
influxBucket = "functional_metrics"
influxOrg = "Functional"

elasticSearchInstance = "http://localhost:9200"
elasticSearchIndex = "performance_metrics"

testrail = os.environ.get("TESTRAIL")
testrail_endpoint = os.environ.get("TESTRAIL_ENDPOINT")
testrail_user = os.environ.get("TESTRAIL_USER")
testrail_password = os.environ.get("TESTRAIL_PASSWORD")
