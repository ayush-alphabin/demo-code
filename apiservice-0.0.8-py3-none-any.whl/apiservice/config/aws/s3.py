from apiservice.config.aws.session import AwsSession


class S3(AwsSession):
    def __init__(self, region_name, access_key, secret_key):
        super().__init__(access_key, secret_key)
        self.region_name = region_name
        self._client = None
        self._client = self.get_client()

    def get_client(self):
        if not self._client:
            try:
                self._client = AwsSession.session.client("s3")
                return self._client
            except Exception as error:
                raise error

    def upload_file(self, file_name, bucket, object_name):
        try:
            return self._client.upload_file(file_name, bucket, object_name)
        except Exception as error:
            raise error

    def load_file(self, bucket, object_name, file_name):
        try:
            return self._client.download_file(bucket, object_name, file_name)
        except Exception as error:
            raise error
