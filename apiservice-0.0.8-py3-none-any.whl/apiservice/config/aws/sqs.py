from apiservice.config.aws.session import AwsSession


class Sqs(AwsSession):
    def __init__(self, region_name, access_key, secret_key):
        super().__init__(access_key, secret_key)
        self.region_name = region_name
        self._client = None
        self._client = self.get_client()

    def get_client(self):
        if not self._client:
            try:
                self._client = AwsSession.session.client("sqs")
                return self._client
            except Exception as error:
                raise error

    def get_queue_url(self, queue_name):
        try:
            return self._client.get_queue_url(
                QueueName=queue_name,
            )["QueueUrl"]
        except Exception as error:
            raise error

    def receive_message(self, queue_url, max_number_of_messages, wait_time_seconds):
        try:
            return self._client.receive_message(
                QueueUrl=queue_url,
                MaxNumberOfMessages=max_number_of_messages,
                WaitTimeSeconds=wait_time_seconds,
            )
        except Exception as error:
            raise error
