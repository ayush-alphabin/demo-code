from apiservice.config.aws.session import AwsSession


class Lambda(AwsSession):
    def __init__(self, region_name, access_key, secret_key):
        super().__init__(access_key, secret_key)
        self.region_name = region_name
        self._client = None
        self._client = self.get_client()

    def get_client(self):
        if not self._client:
            try:
                self._client = AwsSession.session.client("lambda")
                return self._client
            except Exception as error:
                raise error

    def invoke_lambda(self, function_name, invocation_type, payload, log_Type="Tail"):
        try:
            response = self._client.invoke(FunctionName=function_name,
                                           InvocationType=invocation_type,
                                           Payload=payload,
                                           LogType=log_Type)
            return response
        except Exception as error:
            raise error
