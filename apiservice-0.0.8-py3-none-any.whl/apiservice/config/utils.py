import csv
import os
import json
import xml.etree.ElementTree as ET
from deepdiff import DeepDiff
#from Logger import Logger
from pathlib import Path


class utils:

    @staticmethod
    def makeDir(dir_name):
        # Check whether the specified path exists or not
        isExist = os.path.exists(dir_name)
        if not isExist:
            # Create a new directory because it does not exist
            return os.makedirs(dir_name)

    # Reading content from file
    @staticmethod
    def read_json_file(file_name, dir_name):
        path = utils.get_file_with_json_extension(file_name, dir_name)
        with path.open(mode="r") as f:
            return json.load(f)

    # Writing content into file
    @staticmethod
    def write_json_file(content, file_name, dir_name):
        path = utils.get_file_with_json_extension(file_name, dir_name)
        with path.open(mode="w") as f:
            return json.dump(content, f)

    # select file having json extension
    @staticmethod
    def get_file_with_json_extension(file_name, dir_name):
        BASE_PATH = Path.cwd().joinpath(dir_name)
        if ".json" in file_name:
            path = BASE_PATH.joinpath(file_name)
        else:
            path = BASE_PATH.joinpath(f"{file_name}.json")
        return path

    @staticmethod
    def read_csv_file(path):
        listItems = []
        try:
            with open(path, mode='r') as file:
                # reading the CSV file
                csvFile = csv.reader(file, delimiter=',')
                for lines in csvFile:
                    listItems.append(lines)
        except Exception as e:
            raise Exception("Exception:", e)
        return listItems

    @staticmethod
    def get_xml_node_value(content, path, namespaces):
        xml_tree = ET.fromstring(bytes(content, encoding='utf8'))
        name = xml_tree.find(
            path,
            namespaces)
        return name.text

    @staticmethod
    def convert_string_to_tree(xmlString):
        return ET.fromstring(xmlString)

    @staticmethod
    def xml_compare(x1, x2, excludes=[]):
        """
        Compares two xml etrees
        :param x1: the first tree
        :param x2: the second tree
        :param excludes: list of string of attributes to exclude from comparison
        :return:
            True if both files match
        """

        if x1.tag != x2.tag:
            #Logger.Logger.log_info('Tags do not match: %s and %s' % (x1.tag, x2.tag))
            return False
        for name, value in x1.attrib.items():
            if not name in excludes:
                if x2.attrib.get(name) != value:
                    #Logger.Logger.log_info('Attributes do not match: %s=%r, %s=%r'
                    #                       % (name, value, name, x2.attrib.get(name)))
                    return False
        for name in x2.attrib.keys():
            if not name in excludes:
                if name not in x1.attrib:
                    #Logger.Logger.log_info('x2 has an attribute x1 is missing: %s'
                    #                       % name)
                    return False
        if not utils.text_compare(x1.text, x2.text):
            #Logger.Logger.log_info('text: %r != %r' % (x1.text, x2.text))
            return False
        if not utils.text_compare(x1.tail, x2.tail):
            #Logger.Logger.log_info('tail: %r != %r' % (x1.tail, x2.tail))
            return False
        cl1 = x1.getchildren()
        cl2 = x2.getchildren()
        if len(cl1) != len(cl2):
            #Logger.Logger.log_info('children length differs, %i != %i'
            #                       % (len(cl1), len(cl2)))
            return False

        i = 0
        for c1, c2 in zip(cl1, cl2):
            i += 1
            if not c1.tag in excludes:
                if not utils.xml_compare(c1, c2, excludes):
                    #Logger.Logger.log_info('children %i do not match: %s'
                    #                       % (i, c1.tag))
                    return False
        return True

    @staticmethod
    def text_compare(t1, t2):
        """
        Compare two text strings
        :param t1: text one
        :param t2: text two
        :return:
            True if a match
        """
        if not t1 and not t2:
            return True
        if t1 == '*' or t2 == '*':
            return True
        return (t1 or '').strip() == (t2 or '').strip()

    @staticmethod
    def json_compare(json1, json2):
        return DeepDiff(json1, json2)
